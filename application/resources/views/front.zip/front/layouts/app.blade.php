@include('front/layouts/head')
@include('front/layouts/slider')
@include('front/layouts/content_carousel')
@include('front/layouts/footer')