<div class="container">
    <div class="row">
        <div class="col-md-12 border-img" >
           <!-- <div class="border-img"></div>  -->
        </div>
    </div>
</div>