<div class="container" style="background:#1E1E1E;clear:both;">
<div class="row">
   {{-- <div class="col-md-2 footer-menu">
       <h4 style="color:#fff;" class="footer-nav-head">Headline</h4>
           <li><a href="">Lorem ipsum</a></li>
           <li><a href="">Lorem ipsum</a></li>
           <li><a href="">Lorem</a></li>
           <li><a href="">Lorem ipsum</a></li>
           <li><a href="">Lorem </a></li>
       </div>
       <div class="col-md-2 footer-menu">
       <h4 style="color:#fff;" class="footer-nav-head">Headline</h4>
           <li><a href="">Lorem ipsum</a></li>
           <li><a href="">Lorem psum</a></li>
           <li><a href="">Lorem ip</a></li>
           <li><a href="">Lorem </a></li>
       </div>
       <div class="col-md-2 footer-menu">
       <h4 style="color:#fff;" class="footer-nav-head">Headline</h4>
           <li><a href="">Lorem ipsum</a></li>
           <li><a href="">Lorem </a></li>
           <li><a href="">Lorem ipm</a></li>
       </div>
       <div class="col-md-2 footer-menu">
       <h4 style="color:#fff;" class="footer-nav-head">Headline</h4>
           <li><a href="">Lorem ipsum</a></li>
           <li><a href="">Lorem ip</a></li>
           <li><a href="">Lorem isum</a></li>
       </div>
 --}}       <div class="col-md-12">
       	<p class="text-center" style="color:#888888;">Copyright &copy; knitplusltd.com 2017</p>
       </div>
       </div>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="{{ asset('fronts/js/jquery-2.2.0.min.js')}}"></script>
    <script src="{{ asset('fronts/js/jquery.swipebox.js')}}"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{{ asset('fronts/js/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{ asset('fronts/js/slider.js')}}"></script>
    

 
  
